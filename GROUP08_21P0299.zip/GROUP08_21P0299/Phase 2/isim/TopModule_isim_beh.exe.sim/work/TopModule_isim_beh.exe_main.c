/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_2592010699;
char *WORK_P_1662011600;
char *IEEE_P_1242562249;
char *WORK_P_2053452915;
char *IEEE_P_3620187407;
char *WORK_P_0384903374;
char *WORK_P_2039065742;
char *WORK_P_2407203851;
char *WORK_P_2119250017;
char *WORK_P_3774755215;
char *WORK_P_3155485639;
char *WORK_P_1966318210;
char *WORK_P_2212047538;
char *WORK_P_0579733536;
char *WORK_P_1692719334;
char *IEEE_P_3499444699;
char *STD_STANDARD;
char *WORK_P_1190131910;
char *WORK_P_2990524867;
char *IEEE_P_0774719531;
char *WORK_P_0015564191;
char *IEEE_P_3564397177;
char *STD_TEXTIO;
char *WORK_P_1745595347;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    work_p_1745595347_init();
    work_p_3774755215_init();
    work_p_2119250017_init();
    ieee_p_3499444699_init();
    ieee_p_0774719531_init();
    ieee_p_1242562249_init();
    std_textio_init();
    ieee_p_3564397177_init();
    work_p_1966318210_init();
    work_p_2990524867_init();
    work_a_1130845995_0831356973_init();
    work_p_2407203851_init();
    work_p_0015564191_init();
    work_p_1190131910_init();
    work_p_2039065742_init();
    work_p_0384903374_init();
    work_p_0579733536_init();
    work_p_2053452915_init();
    work_p_1662011600_init();
    work_p_1692719334_init();
    work_p_3155485639_init();
    work_p_2212047538_init();
    work_a_1037769429_3212880686_init();
    work_a_2991416129_3212880686_init();
    work_a_1208337864_3212880686_init();
    ieee_p_3620187407_init();
    work_a_3714479754_3212880686_init();
    work_a_1153420228_3212880686_init();
    work_a_2077859724_3212880686_init();
    work_a_3215900657_3212880686_init();
    work_a_3660693623_3212880686_init();
    work_a_3203354104_3212880686_init();
    work_a_1506983852_3212880686_init();
    work_a_2166523021_3212880686_init();
    work_a_0532180842_3212880686_init();
    work_a_1196643129_3212880686_init();
    work_a_2399776393_3212880686_init();
    work_a_1430113433_3212880686_init();
    work_a_3720894149_0831356973_init();
    work_a_1504297269_3212880686_init();


    xsi_register_tops("work_a_1504297269_3212880686");

    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    WORK_P_1662011600 = xsi_get_engine_memory("work_p_1662011600");
    IEEE_P_1242562249 = xsi_get_engine_memory("ieee_p_1242562249");
    WORK_P_2053452915 = xsi_get_engine_memory("work_p_2053452915");
    IEEE_P_3620187407 = xsi_get_engine_memory("ieee_p_3620187407");
    WORK_P_0384903374 = xsi_get_engine_memory("work_p_0384903374");
    WORK_P_2039065742 = xsi_get_engine_memory("work_p_2039065742");
    WORK_P_2407203851 = xsi_get_engine_memory("work_p_2407203851");
    WORK_P_2119250017 = xsi_get_engine_memory("work_p_2119250017");
    WORK_P_3774755215 = xsi_get_engine_memory("work_p_3774755215");
    WORK_P_3155485639 = xsi_get_engine_memory("work_p_3155485639");
    WORK_P_1966318210 = xsi_get_engine_memory("work_p_1966318210");
    WORK_P_2212047538 = xsi_get_engine_memory("work_p_2212047538");
    WORK_P_0579733536 = xsi_get_engine_memory("work_p_0579733536");
    WORK_P_1692719334 = xsi_get_engine_memory("work_p_1692719334");
    IEEE_P_3499444699 = xsi_get_engine_memory("ieee_p_3499444699");
    STD_STANDARD = xsi_get_engine_memory("std_standard");
    WORK_P_1190131910 = xsi_get_engine_memory("work_p_1190131910");
    WORK_P_2990524867 = xsi_get_engine_memory("work_p_2990524867");
    IEEE_P_0774719531 = xsi_get_engine_memory("ieee_p_0774719531");
    WORK_P_0015564191 = xsi_get_engine_memory("work_p_0015564191");
    IEEE_P_3564397177 = xsi_get_engine_memory("ieee_p_3564397177");
    STD_TEXTIO = xsi_get_engine_memory("std_textio");
    WORK_P_1745595347 = xsi_get_engine_memory("work_p_1745595347");

    return xsi_run_simulation(argc, argv);

}
