/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/Phase2/ALU32.vhd";
extern char *IEEE_P_3620187407;
extern char *IEEE_P_2592010699;

char *ieee_p_2592010699_sub_1306069469_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_3620187407_sub_1742983514_3965413181(char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767668596_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_1196643129_3212880686_p_0(char *t0)
{
    char t5[16];
    char t11[16];
    char t13[16];
    char t18[16];
    char t34[16];
    char t40[16];
    char t42[16];
    char t47[16];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned char t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned char t39;
    char *t41;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    unsigned int t52;
    unsigned char t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;

LAB0:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6744U);
    t3 = (t0 + 6997);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 3;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (3 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB3;

LAB4:    t30 = (t0 + 1352U);
    t31 = *((char **)t30);
    t30 = (t0 + 6744U);
    t32 = (t0 + 7001);
    t35 = (t34 + 0U);
    t36 = (t35 + 0U);
    *((int *)t36) = 0;
    t36 = (t35 + 4U);
    *((int *)t36) = 3;
    t36 = (t35 + 8U);
    *((int *)t36) = 1;
    t37 = (3 - 0);
    t38 = (t37 * 1);
    t38 = (t38 + 1);
    t36 = (t35 + 12U);
    *((unsigned int *)t36) = t38;
    t39 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t31, t30, t32, t34);
    if (t39 != 0)
        goto LAB7;

LAB8:
LAB11:    t59 = xsi_get_transient_memory(33U);
    memset(t59, 0, 33U);
    t60 = t59;
    memset(t60, (unsigned char)2, 33U);
    t61 = (t0 + 4768);
    t62 = (t61 + 56U);
    t63 = *((char **)t62);
    t64 = (t63 + 56U);
    t65 = *((char **)t64);
    memcpy(t65, t59, 33U);
    xsi_driver_first_trans_fast(t61);

LAB2:    t66 = (t0 + 4624);
    *((int *)t66) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 1032U);
    t12 = *((char **)t7);
    t14 = ((IEEE_P_2592010699) + 4024);
    t15 = (t0 + 6712U);
    t7 = xsi_base_array_concat(t7, t13, t14, (char)99, (unsigned char)2, (char)97, t12, t15, (char)101);
    t16 = (t0 + 1192U);
    t17 = *((char **)t16);
    t19 = ((IEEE_P_2592010699) + 4024);
    t20 = (t0 + 6728U);
    t16 = xsi_base_array_concat(t16, t18, t19, (char)99, (unsigned char)2, (char)97, t17, t20, (char)101);
    t21 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t11, t7, t13, t16, t18);
    t22 = (t11 + 12U);
    t9 = *((unsigned int *)t22);
    t23 = (1U * t9);
    t24 = (33U != t23);
    if (t24 == 1)
        goto LAB5;

LAB6:    t25 = (t0 + 4768);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    t28 = (t27 + 56U);
    t29 = *((char **)t28);
    memcpy(t29, t21, 33U);
    xsi_driver_first_trans_fast(t25);
    goto LAB2;

LAB5:    xsi_size_not_matching(33U, t23, 0);
    goto LAB6;

LAB7:    t36 = (t0 + 1032U);
    t41 = *((char **)t36);
    t43 = ((IEEE_P_2592010699) + 4024);
    t44 = (t0 + 6712U);
    t36 = xsi_base_array_concat(t36, t42, t43, (char)99, (unsigned char)2, (char)97, t41, t44, (char)101);
    t45 = (t0 + 1192U);
    t46 = *((char **)t45);
    t48 = ((IEEE_P_2592010699) + 4024);
    t49 = (t0 + 6728U);
    t45 = xsi_base_array_concat(t45, t47, t48, (char)99, (unsigned char)2, (char)97, t46, t49, (char)101);
    t50 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t40, t36, t42, t45, t47);
    t51 = (t40 + 12U);
    t38 = *((unsigned int *)t51);
    t52 = (1U * t38);
    t53 = (33U != t52);
    if (t53 == 1)
        goto LAB9;

LAB10:    t54 = (t0 + 4768);
    t55 = (t54 + 56U);
    t56 = *((char **)t55);
    t57 = (t56 + 56U);
    t58 = *((char **)t57);
    memcpy(t58, t50, 33U);
    xsi_driver_first_trans_fast(t54);
    goto LAB2;

LAB9:    xsi_size_not_matching(33U, t52, 0);
    goto LAB10;

LAB12:    goto LAB2;

}

static void work_a_1196643129_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    unsigned char t5;
    char *t6;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(25, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 6712U);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 6728U);
    t5 = ieee_p_3620187407_sub_1742983514_3965413181(IEEE_P_3620187407, t2, t1, t4, t3);
    if (t5 != 0)
        goto LAB3;

LAB4:
LAB5:    t13 = (t0 + 7037);
    t15 = (t0 + 4832);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t13, 32U);
    xsi_driver_first_trans_fast(t15);

LAB2:    t20 = (t0 + 4640);
    *((int *)t20) = 1;

LAB1:    return;
LAB3:    t6 = (t0 + 7005);
    t8 = (t0 + 4832);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t6, 32U);
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_1196643129_3212880686_p_2(char *t0)
{
    char t5[16];
    char t11[16];
    char t28[16];
    char t34[16];
    char t51[16];
    char t69[16];
    char t87[16];
    char t93[16];
    char t110[16];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    unsigned int t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t29;
    char *t30;
    int t31;
    unsigned int t32;
    unsigned char t33;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    unsigned int t40;
    unsigned char t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t52;
    char *t53;
    int t54;
    unsigned int t55;
    unsigned char t56;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t70;
    char *t71;
    int t72;
    unsigned int t73;
    unsigned char t74;
    char *t75;
    unsigned int t76;
    unsigned int t77;
    char *t78;
    char *t79;
    char *t80;
    char *t81;
    char *t82;
    char *t83;
    char *t84;
    char *t85;
    char *t88;
    char *t89;
    int t90;
    unsigned int t91;
    unsigned char t92;
    char *t94;
    char *t95;
    char *t96;
    char *t97;
    char *t98;
    unsigned int t99;
    unsigned char t100;
    char *t101;
    char *t102;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    char *t107;
    char *t108;
    char *t111;
    char *t112;
    int t113;
    unsigned int t114;
    unsigned char t115;
    char *t116;
    char *t117;
    char *t118;
    char *t119;
    char *t120;
    char *t121;

LAB0:    xsi_set_current_line(27, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 6744U);
    t3 = (t0 + 7069);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 3;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (3 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB3;

LAB4:    t24 = (t0 + 1352U);
    t25 = *((char **)t24);
    t24 = (t0 + 6744U);
    t26 = (t0 + 7073);
    t29 = (t28 + 0U);
    t30 = (t29 + 0U);
    *((int *)t30) = 0;
    t30 = (t29 + 4U);
    *((int *)t30) = 3;
    t30 = (t29 + 8U);
    *((int *)t30) = 1;
    t31 = (3 - 0);
    t32 = (t31 * 1);
    t32 = (t32 + 1);
    t30 = (t29 + 12U);
    *((unsigned int *)t30) = t32;
    t33 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t25, t24, t26, t28);
    if (t33 != 0)
        goto LAB7;

LAB8:    t47 = (t0 + 1352U);
    t48 = *((char **)t47);
    t47 = (t0 + 6744U);
    t49 = (t0 + 7077);
    t52 = (t51 + 0U);
    t53 = (t52 + 0U);
    *((int *)t53) = 0;
    t53 = (t52 + 4U);
    *((int *)t53) = 3;
    t53 = (t52 + 8U);
    *((int *)t53) = 1;
    t54 = (3 - 0);
    t55 = (t54 * 1);
    t55 = (t55 + 1);
    t53 = (t52 + 12U);
    *((unsigned int *)t53) = t55;
    t56 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t48, t47, t49, t51);
    if (t56 != 0)
        goto LAB11;

LAB12:    t65 = (t0 + 1352U);
    t66 = *((char **)t65);
    t65 = (t0 + 6744U);
    t67 = (t0 + 7081);
    t70 = (t69 + 0U);
    t71 = (t70 + 0U);
    *((int *)t71) = 0;
    t71 = (t70 + 4U);
    *((int *)t71) = 3;
    t71 = (t70 + 8U);
    *((int *)t71) = 1;
    t72 = (3 - 0);
    t73 = (t72 * 1);
    t73 = (t73 + 1);
    t71 = (t70 + 12U);
    *((unsigned int *)t71) = t73;
    t74 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t66, t65, t67, t69);
    if (t74 != 0)
        goto LAB13;

LAB14:    t83 = (t0 + 1352U);
    t84 = *((char **)t83);
    t83 = (t0 + 6744U);
    t85 = (t0 + 7085);
    t88 = (t87 + 0U);
    t89 = (t88 + 0U);
    *((int *)t89) = 0;
    t89 = (t88 + 4U);
    *((int *)t89) = 3;
    t89 = (t88 + 8U);
    *((int *)t89) = 1;
    t90 = (3 - 0);
    t91 = (t90 * 1);
    t91 = (t91 + 1);
    t89 = (t88 + 12U);
    *((unsigned int *)t89) = t91;
    t92 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t84, t83, t85, t87);
    if (t92 != 0)
        goto LAB15;

LAB16:    t106 = (t0 + 1352U);
    t107 = *((char **)t106);
    t106 = (t0 + 6744U);
    t108 = (t0 + 7089);
    t111 = (t110 + 0U);
    t112 = (t111 + 0U);
    *((int *)t112) = 0;
    t112 = (t111 + 4U);
    *((int *)t112) = 3;
    t112 = (t111 + 8U);
    *((int *)t112) = 1;
    t113 = (3 - 0);
    t114 = (t113 * 1);
    t114 = (t114 + 1);
    t112 = (t111 + 12U);
    *((unsigned int *)t112) = t114;
    t115 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t107, t106, t108, t110);
    if (t115 != 0)
        goto LAB19;

LAB20:
LAB2:    t121 = (t0 + 4656);
    *((int *)t121) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 1032U);
    t12 = *((char **)t7);
    t7 = (t0 + 6712U);
    t13 = (t0 + 1192U);
    t14 = *((char **)t13);
    t13 = (t0 + 6728U);
    t15 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t11, t12, t7, t14, t13);
    t16 = (t11 + 12U);
    t9 = *((unsigned int *)t16);
    t17 = (1U * t9);
    t18 = (32U != t17);
    if (t18 == 1)
        goto LAB5;

LAB6:    t19 = (t0 + 4896);
    t20 = (t19 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memcpy(t23, t15, 32U);
    xsi_driver_first_trans_fast(t19);
    goto LAB2;

LAB5:    xsi_size_not_matching(32U, t17, 0);
    goto LAB6;

LAB7:    t30 = (t0 + 1032U);
    t35 = *((char **)t30);
    t30 = (t0 + 6712U);
    t36 = (t0 + 1192U);
    t37 = *((char **)t36);
    t36 = (t0 + 6728U);
    t38 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t34, t35, t30, t37, t36);
    t39 = (t34 + 12U);
    t32 = *((unsigned int *)t39);
    t40 = (1U * t32);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB9;

LAB10:    t42 = (t0 + 4896);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    memcpy(t46, t38, 32U);
    xsi_driver_first_trans_fast(t42);
    goto LAB2;

LAB9:    xsi_size_not_matching(32U, t40, 0);
    goto LAB10;

LAB11:    t53 = (t0 + 2152U);
    t57 = *((char **)t53);
    t55 = (32 - 31);
    t58 = (t55 * 1U);
    t59 = (0 + t58);
    t53 = (t57 + t59);
    t60 = (t0 + 4896);
    t61 = (t60 + 56U);
    t62 = *((char **)t61);
    t63 = (t62 + 56U);
    t64 = *((char **)t63);
    memcpy(t64, t53, 32U);
    xsi_driver_first_trans_fast(t60);
    goto LAB2;

LAB13:    t71 = (t0 + 2152U);
    t75 = *((char **)t71);
    t73 = (32 - 31);
    t76 = (t73 * 1U);
    t77 = (0 + t76);
    t71 = (t75 + t77);
    t78 = (t0 + 4896);
    t79 = (t78 + 56U);
    t80 = *((char **)t79);
    t81 = (t80 + 56U);
    t82 = *((char **)t81);
    memcpy(t82, t71, 32U);
    xsi_driver_first_trans_fast(t78);
    goto LAB2;

LAB15:    t89 = (t0 + 1032U);
    t94 = *((char **)t89);
    t89 = (t0 + 6712U);
    t95 = (t0 + 1192U);
    t96 = *((char **)t95);
    t95 = (t0 + 6728U);
    t97 = ieee_p_2592010699_sub_1306069469_503743352(IEEE_P_2592010699, t93, t94, t89, t96, t95);
    t98 = (t93 + 12U);
    t91 = *((unsigned int *)t98);
    t99 = (1U * t91);
    t100 = (32U != t99);
    if (t100 == 1)
        goto LAB17;

LAB18:    t101 = (t0 + 4896);
    t102 = (t101 + 56U);
    t103 = *((char **)t102);
    t104 = (t103 + 56U);
    t105 = *((char **)t104);
    memcpy(t105, t97, 32U);
    xsi_driver_first_trans_fast(t101);
    goto LAB2;

LAB17:    xsi_size_not_matching(32U, t99, 0);
    goto LAB18;

LAB19:    t112 = (t0 + 1992U);
    t116 = *((char **)t112);
    t112 = (t0 + 4896);
    t117 = (t112 + 56U);
    t118 = *((char **)t117);
    t119 = (t118 + 56U);
    t120 = *((char **)t119);
    memcpy(t120, t116, 32U);
    xsi_driver_first_trans_fast(t112);
    goto LAB2;

}

static void work_a_1196643129_3212880686_p_3(char *t0)
{
    char t5[16];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    xsi_set_current_line(33, ng0);
    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t1 = (t0 + 6776U);
    t3 = (t0 + 7093);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 31;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (31 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_std_logic_unsigned_equal_stdv_stdv(IEEE_P_3620187407, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB3;

LAB4:
LAB5:    t15 = (t0 + 4960);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    *((unsigned char *)t19) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t15);

LAB2:    t20 = (t0 + 4672);
    *((int *)t20) = 1;

LAB1:    return;
LAB3:    t7 = (t0 + 4960);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t7);
    goto LAB2;

LAB6:    goto LAB2;

}

static void work_a_1196643129_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(35, ng0);

LAB3:    t1 = (t0 + 1832U);
    t2 = *((char **)t1);
    t1 = (t0 + 5024);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 4688);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_1196643129_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1196643129_3212880686_p_0,(void *)work_a_1196643129_3212880686_p_1,(void *)work_a_1196643129_3212880686_p_2,(void *)work_a_1196643129_3212880686_p_3,(void *)work_a_1196643129_3212880686_p_4};
	xsi_register_didat("work_a_1196643129_3212880686", "isim/TopModule_isim_beh.exe.sim/work/a_1196643129_3212880686.didat");
	xsi_register_executes(pe);
}
